
const name = document.getElementById("name");
const lastname = document.getElementById("lastname");
const signIn = document.getElementById("signIn");
const output = document.getElementById("output");
const code = document.getElementById("code");
const fName = document.getElementById('f-Name')
const nameList = []
let nameListText = ""
signIn.addEventListener("click", () => {
    const reg = {
        Name: name.value,
        LastName: lastname.value,
        Code: code.value,
        FName:fName.value
    }
    nameList.push(reg);
    nameListText += "<li> esm: " + reg.Name + " famil: " + reg.LastName + " code: " + reg.Code + " esm pedar: " + reg.FName + "</li>";
    output.innerHTML = nameListText





})
